import re
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout

def parse_code(code_str):
    # Regular expressions to extract code blocks
    pattern_import = r"fr\s+(\S+)\s+im\s+(\S+)"
    pattern_class = r"cls\s+(\w+)\(([\w,]+)\)\s*\{(.*?)\}"  # Updated pattern to match class block
    pattern_var_list = r"list\s+(\w+)\s*\[(.*?)\]"  # Pattern to match variable lists
    pattern_func_list = r"fnc\s+(\w+)\((.*?)\)\s*\{(.*?)\}"  # Pattern to match function lists

    # Find import statements, class definitions, variable lists, and function lists
    imports = re.findall(pattern_import, code_str)
    classes = re.findall(pattern_class, code_str, re.DOTALL)
    var_lists = re.findall(pattern_var_list, code_str, re.DOTALL)
    func_lists = re.findall(pattern_func_list, code_str, re.DOTALL)

    return imports, classes, var_lists, func_lists

def execute_code(code_str):
    imports, classes, var_lists, func_lists = parse_code(code_str)

    # Execute import statements
    for module, object_name in imports:
        exec(f"from {module} import {object_name}")

    # Execute variable lists
    for var_name, var_values in var_lists:
        var_values = [eval(val.strip()) for val in var_values.split(",")]
        exec(f"{var_name} = {var_values}")

    # Execute function lists
    for func_name, func_args, func_body in func_lists:
        func_definition = f"""def {func_name}({func_args}):\n    {func_body}"""
        exec(func_definition, globals())

    # Execute class definitions
    for class_name, parent, class_body in classes:
        # Replace custom "prt" statements with "print"
        class_body = class_body.replace("prt", "print")
        class_body = class_body.replace("\n", "\n    ")  # Add indentation
        class_definition = f"""class {class_name}({parent}):\n    {class_body}"""
        exec(class_definition, globals())

if __name__ == "__main__":
    code_str = """
__type__ :: __kernel__
__code__ :: {
    fr Camera im CameraWidget
    fr Application im Application
    fr PyQt6.QtWidgets im QWidget
    list data [1, 2, 3, 4, 5]  # Custom variable list
    fnc print_data(self):  # Custom function list
        prt("Data List:", data)

    cls AppWidget(QWidget){
        fnc __init__(self, parent=None){
            sup().__init__(parent)
            self.setWindowTitle("bob")
            self.resize(640,480)
            layout :: QVBoxLayout()
            layout.setContentsMargins(0,0,0,0)
            self.setLayout(layout)
            cam :: CameraWidget(self)
            self.layout().addWidget(cam)
            cam.show()
            prt("Hello, this is custom prt statement.")
            self.print_data()  # Call the custom function
        }
    }

    if __name__ :: "__main__"{
        app :: QApplication([])
        aw :: AppWidget()
        aw.show()
        app.exec()
    }
}
"""
    execute_code(code_str)
    print(parse_code(code_str))
