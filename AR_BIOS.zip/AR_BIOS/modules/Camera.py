import cv2
from PyQt6.QtWidgets import QLabel, QWidget
from PyQt6.QtGui import QImage, QPixmap
from HandTracking import handTracker
from PyQt6.QtCore import QTimer

class CameraWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.tracker = handTracker()

        # Set up the camera
        self.camera_width = 640
        self.camera_height = 480
        self.cap = cv2.VideoCapture(0)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.camera_width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.camera_height)

        # Set up the GUI
        self.label = QLabel(self)
        self.label.setGeometry(0, 0, self.camera_width, self.camera_height)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(1)

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return

        # Rotate the frame (if needed)

        # Convert the frame to RGB
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        frame_rgb = self.tracker.handsFinder(frame_rgb, True)
        lmList = self.tracker.positionFinder(frame_rgb)

        if len(lmList) != 0:
            pass

        # Create a QImage from the frame
        height, width, channel = frame_rgb.shape
        bytes_per_line = channel * width
        q_image = QImage(frame_rgb.data, width, height, bytes_per_line, QImage.Format.Format_RGB888)

        # Create a QPixmap from the QImage
        pixmap = QPixmap.fromImage(q_image)

        # Display the QPixmap on the QLabel
        self.label.setPixmap(pixmap)

    def closeEvent(self, event):
        self.cap.release()

    def setTitle(self, title):
        self.setWindowTitle(title)
