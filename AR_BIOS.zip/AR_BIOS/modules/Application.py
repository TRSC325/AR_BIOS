import sys
from PyQt6.QtWidgets import QApplication, QWidget, QLabel

class Application(QApplication):
    def __init__(self):
        self.app = QApplication(sys.argv)
    def stop(self):
        sys.exit(self.app.exec())

