from PyQt6.QtWidgets import QVBoxLayout
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWidgets import QWidget
from PyQt6.QtGui import QColor
from PyQt6.QtGui import QPainter
from PyQt6.QtCore import QUrl



class Window(QWidget):
    def __init__(self, parent=None, x=0, y=0, width=100, height=100, title="Window", bg=(255, 255, 255)):
        super().__init__(parent)
        self.setGeometry(x, y, width, height)
        self.setWindowTitle(title)
        self.bg_color = QColor(*bg)

        self.elements = []  # List to store added elements

        self.layout = QVBoxLayout(self)
        self.setLayout(self.layout)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), self.bg_color)

    def add_text(self, text, x, y):
        label = QLabel(self)
        label.setText(text)
        label.move(x, y)
        label.show()
        self.elements.append(label)

    def add_image(self, image_path, x, y):
        label = QLabel(self)
        pixmap = QPixmap(image_path)
        label.setPixmap(pixmap)
        label.setGeometry(x, y, pixmap.width(), pixmap.height())
        label.show()
        self.elements.append(label)
    def load_webpage(self, url):
        web_view = QWebEngineView(self)
        web_view.load(QUrl(url))
        self.layout.addWidget(web_view)
        self.elements.append(web_view)
