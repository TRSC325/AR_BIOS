import re
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout
from Parser import Parser
pars = Parser()
f = open("test.os","r")
data = f.read()
pars.execute_code(data)
