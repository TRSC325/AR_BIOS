shortlink = [
    {"key":"furry://browser","link":"https://4a70ff83-6916-4684-a497-fb0e3096ebdd.pages.dev/:}
]

