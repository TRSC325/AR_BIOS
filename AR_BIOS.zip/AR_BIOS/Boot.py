class Boot:
    def __init__(self, size):
        self.size = size * 1024 * 1024*1024
        self.allocation_counter = 0
        self.data = []
        self.memleft = size * 1024 * 1024*1024

    def allocation(self, data):
        total_size = 0
        for item in data:
            if isinstance(item, int):
                total_size += item
            else:
                size = self.getSizeOfFile(item)  # Assuming this method is defined correctly
                if isinstance(size, int) and size > 0:
                    total_size += size

        if self.allocation_counter + total_size <= self.size:
            hexcode = len(self.data)
            for item in data:
                self.data.append(item)
                if isinstance(item, int):
                    self.allocation_counter += item
                    self.memleft -= item
                else:
                    size = self.getSizeOfFile(item)
                    if isinstance(size, int) and size > 0:
                        self.allocation_counter += size
                        self.memleft -= size
            return hexcode
        else:
            return -1  # Return -1 to indicate failure



    def deallocation(self, hexcode):
        if 0 <= hexcode < len(self.data):  # Check if hexcode is within bounds
            if self.data[hexcode]:
                self.allocation_counter -= len(self.data[hexcode])
                self.memleft += len(self.data[hexcode])
                self.data.pop(hexcode)

    def allocated(self):
        return self.allocation_counter

    def memLeft(self):
        return self.memleft

    def getSizeOfFile(self, data):
        ln = len(data)
        a = 0
        i = 0
        while i < ln:
            if not isinstance(data[i], int):
                a += len(data[i])
            i += 1
        return a
    


f = open("test.os","r")
dat = f.read()
data = dat.replace("    ","")
data = data.split("\n")
print(data)
boot = Boot(64)
hexcode = boot.allocation(data)
memleft = boot.memLeft()  # Corrected method name
print(memleft/1024/1024/1024)  # Output remaining memory
print(boot.allocated()/1024/1024/1024)
print((memleft + boot.allocated())/1024/1024/1024)


